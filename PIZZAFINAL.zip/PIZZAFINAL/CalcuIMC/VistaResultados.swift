//
//  VistaResultados.swift
//  CalcuIMC
//
//  Created by Felipe Mojica on 30/01/17.
//  Copyright © 2017 Felipe Mojica. All rights reserved.
//

import UIKit

class VistaResultados: UIViewController {
    
    
    var pizzza:String = ""
   

    
    @IBOutlet weak var pizzafinal: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        //resultadoIMC.text=String(indiceIM)
        pizzafinal.text=pizzza
       
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
