//
//  ViewController.swift
//  CalcuIMC
//
//  Created by Felipe Mojica on 30/01/17.
//  Copyright © 2017 Felipe Mojica. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    // @IBOutlet weak var peso: UITextField!
   // @IBOutlet weak var estatura: UITextField!
    
    @IBOutlet weak var ingre: UITextField!
    @IBOutlet weak var ques: UITextField!
    @IBOutlet weak var mas: UITextField!
    @IBOutlet weak var tama: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //peso.delegate=self
        //estatura.delegate=self
        ingre.delegate=self
        ques.delegate=self
        mas.delegate=self
        tama.delegate=self
    }
    
    
    /*
    @IBAction func backgroundTap(sender:UIControl){
        
        peso.resignFirstResponder()
        estatura.resignFirstResponder()
    }
*/
    @IBAction func textFieldDidEndEditing(_ textField: UITextField) {
        
        textField.resignFirstResponder() // desaparecer el teclado

    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let resultado=pizza()
        let sigVista=segue.destination as! VistaResultados
      //  sigVista.indiceIM=resultado
        sigVista.pizzza=resultado
        
    }
    @IBAction func calcularIMC(_ sender: Any) {
       pizza()
        
    }
   func pizza()->String{
        let tamaño:String = (self.tama.text!)
        let masa:String = (self.mas.text!)
        let queso:String = (self.ques.text!)
        let ingredientes:String = (self.ingre.text!)
        var pizza:String = " "
        
        pizza=("Tamaño: \(tamaño)\n Masa: \(masa)\n Queso: \(queso)\n Ingredientes: \(ingredientes)\n")
    
        print(pizza)
    
        return pizza
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

